import { useEffect, useMemo, useState } from "react";
import { PhaserCanvas } from "./components/PhaserCanvas";
import { gameBridge, type RendererTelemetry } from "./game/bridge";
import { useWorldSimulation } from "./simulation/useWorldSimulation";

const PLAYER_FACTION_ID = "faction.aurelia";
const PLAYER_ARMY_ID = "army.first-frontier";

export function App(): React.JSX.Element {
  const simulation = useWorldSimulation(10);
  const [selectedProvince, setSelectedProvince] = useState("province.western-gate");
  const [telemetry, setTelemetry] = useState<RendererTelemetry>();

  useEffect(() => {
    const removeProvinceListener = gameBridge.on("province-selected", (event) => {
      setSelectedProvince(event.detail);
    });
    const removeTelemetryListener = gameBridge.on("renderer-telemetry", (event) => {
      setTelemetry(event.detail);
    });
    return () => {
      removeProvinceListener();
      removeTelemetryListener();
    };
  }, []);

  const playerArmy = useMemo(
    () => simulation.readModel?.armies.find((army) => army.id === PLAYER_ARMY_ID),
    [simulation.readModel],
  );
  const selectedProvinceRecord = simulation.readModel?.provinces.find(
    (province) => province.id === selectedProvince,
  );

  const moveArmy = (): void => {
    if (!playerArmy) {
      return;
    }
    const destinationProvinceId =
      playerArmy.provinceId === "province.western-gate"
        ? "province.river-crossing"
        : "province.western-gate";
    simulation.submit(PLAYER_FACTION_ID, {
      type: "army.move",
      armyId: playerArmy.id,
      destinationProvinceId,
    });
  };

  const endTurn = (): void => {
    simulation.submit(PLAYER_FACTION_ID, { type: "strategic.end-turn" });
  };

  return (
    <main className="app-shell">
      <header className="topbar">
        <div>
          <p className="eyebrow">Cursor Game Development Kit</p>
          <h1>Ancient World Strategy</h1>
        </div>
        <div className="turn-readout" aria-live="polite">
          <span>Turn {simulation.readModel?.turn ?? "—"}</span>
          <code>{simulation.readModel?.stateHash ?? "initializing"}</code>
        </div>
      </header>

      <section className="workspace">
        <PhaserCanvas />

        <aside className="control-panel">
          <section>
            <h2>Simulation worker</h2>
            <dl className="stat-grid">
              <div>
                <dt>Status</dt>
                <dd>{simulation.isReady ? "Ready" : "Starting"}</dd>
              </div>
              <div>
                <dt>Revision</dt>
                <dd>{simulation.readModel?.revision ?? 0}</dd>
              </div>
              <div>
                <dt>Army</dt>
                <dd>{playerArmy?.strength.toLocaleString() ?? "—"}</dd>
              </div>
              <div>
                <dt>Move points</dt>
                <dd>{playerArmy?.movementPoints ?? "—"}</dd>
              </div>
            </dl>
            <div className="button-row">
              <button type="button" onClick={moveArmy} disabled={!simulation.isReady}>
                Move army
              </button>
              <button type="button" onClick={endTurn} disabled={!simulation.isReady}>
                End turn
              </button>
            </div>
            {simulation.error ? <p className="error-message">{simulation.error}</p> : null}
          </section>

          <section>
            <h2>Selected province</h2>
            <p className="primary-value">
              {selectedProvinceRecord?.name ?? selectedProvince.replace("province.", "")}
            </p>
            <p>
              Food: {selectedProvinceRecord?.food ?? "—"} · Unrest:{" "}
              {selectedProvinceRecord?.unrest ?? "—"}
            </p>
          </section>

          <section>
            <h2>Renderer scenes</h2>
            <div className="button-row">
              <button type="button" onClick={() => gameBridge.requestScene("StrategicMap")}>
                Strategic map
              </button>
              <button type="button" onClick={() => gameBridge.requestScene("BattleBenchmark")}>
                10K benchmark
              </button>
            </div>
            {telemetry ? (
              <p className="telemetry">
                {telemetry.framesPerSecond} FPS · {telemetry.visualInstances.toLocaleString()} visuals
                <small>{telemetry.note}</small>
              </p>
            ) : (
              <p className="muted">Open the benchmark to begin renderer telemetry.</p>
            )}
          </section>

          <section>
            <h2>Last events</h2>
            {simulation.lastEvents.length === 0 ? (
              <p className="muted">No commands resolved yet.</p>
            ) : (
              <ol className="event-list">
                {simulation.lastEvents.slice(-5).map((event) => (
                  <li key={`${event.type}-${event.sequence}`}>{event.type}</li>
                ))}
              </ol>
            )}
          </section>
        </aside>
      </section>
    </main>
  );
}
