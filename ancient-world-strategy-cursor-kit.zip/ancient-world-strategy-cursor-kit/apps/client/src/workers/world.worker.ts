/// <reference lib="webworker" />

import {
  buildWorldReadModel,
  createSampleWorld,
  executeCommand,
  type WorldState,
} from "@ancient/sim-core";
import type { WorldWorkerRequest, WorldWorkerResponse } from "./worldWorkerProtocol";

let world: WorldState | undefined;

function post(response: WorldWorkerResponse): void {
  self.postMessage(response);
}

self.onmessage = (event: MessageEvent<WorldWorkerRequest>): void => {
  try {
    switch (event.data.type) {
      case "world.initialize": {
        world = createSampleWorld(event.data.seed);
        post({ type: "world.snapshot", readModel: buildWorldReadModel(world), events: [] });
        break;
      }
      case "world.command": {
        if (!world) {
          throw new Error("World worker received a command before initialization.");
        }
        const result = executeCommand(world, event.data.envelope);
        if (!result.ok) {
          post({ type: "world.rejected", error: result.error });
          return;
        }
        world = result.state;
        post({
          type: "world.snapshot",
          readModel: buildWorldReadModel(world),
          events: result.events,
        });
        break;
      }
      default: {
        const exhaustive: never = event.data;
        throw new Error(`Unhandled worker request: ${JSON.stringify(exhaustive)}`);
      }
    }
  } catch (error: unknown) {
    post({
      type: "world.crashed",
      message: error instanceof Error ? error.message : "Unknown world worker failure.",
    });
  }
};
