import type {
  CommandEnvelope,
  CommandFailure,
  WorldEvent,
  WorldReadModel,
} from "@ancient/sim-core";

export type WorldWorkerRequest =
  | {
      type: "world.initialize";
      seed: number;
    }
  | {
      type: "world.command";
      envelope: CommandEnvelope;
    };

export type WorldWorkerResponse =
  | {
      type: "world.snapshot";
      readModel: WorldReadModel;
      events: WorldEvent[];
    }
  | {
      type: "world.rejected";
      error: CommandFailure;
    }
  | {
      type: "world.crashed";
      message: string;
    };
