import Phaser from "phaser";
import { gameBridge, type GameSceneId } from "../bridge";

interface ProvinceVisual {
  id: string;
  name: string;
  points: Array<{ x: number; y: number }>;
  fill: number;
  labelX: number;
  labelY: number;
}

const PROVINCES: ProvinceVisual[] = [
  {
    id: "province.western-gate",
    name: "Western Gate",
    points: [
      { x: 80, y: 130 },
      { x: 330, y: 80 },
      { x: 380, y: 290 },
      { x: 130, y: 350 },
    ],
    fill: 0x6f7652,
    labelX: 225,
    labelY: 205,
  },
  {
    id: "province.river-crossing",
    name: "River Crossing",
    points: [
      { x: 330, y: 80 },
      { x: 590, y: 105 },
      { x: 620, y: 340 },
      { x: 380, y: 290 },
    ],
    fill: 0x856d46,
    labelX: 480,
    labelY: 205,
  },
  {
    id: "province.eastern-march",
    name: "Eastern March",
    points: [
      { x: 590, y: 105 },
      { x: 875, y: 135 },
      { x: 835, y: 375 },
      { x: 620, y: 340 },
    ],
    fill: 0x6a5a70,
    labelX: 735,
    labelY: 235,
  },
];

export class StrategicMapScene extends Phaser.Scene {
  #removeSceneListener: (() => void) | undefined;

  constructor() {
    super("StrategicMap");
  }

  create(): void {
    this.cameras.main.setBackgroundColor(0x171a17);
    this.add
      .text(24, 18, "STRATEGIC MAP · TECHNICAL SLICE", {
        fontFamily: "monospace",
        fontSize: "20px",
        color: "#f1e3b7",
      })
      .setScrollFactor(0)
      .setDepth(100);
    this.add
      .text(24, 48, "Select a province. Press B or use the UI to open the 10,000-unit benchmark.", {
        fontFamily: "system-ui",
        fontSize: "14px",
        color: "#b9b6a7",
      })
      .setScrollFactor(0)
      .setDepth(100);

    for (const province of PROVINCES) {
      const polygon = new Phaser.Geom.Polygon(province.points);
      const shape = this.add.polygon(0, 0, province.points, province.fill, 1);
      shape.setOrigin(0, 0);
      shape.setStrokeStyle(3, 0xd4c18f, 0.75);
      shape.setInteractive(polygon, Phaser.Geom.Polygon.Contains);
      shape.on("pointerover", () => shape.setAlpha(0.82));
      shape.on("pointerout", () => shape.setAlpha(1));
      shape.on("pointerdown", () => {
        gameBridge.publishProvinceSelection(province.id);
        shape.setStrokeStyle(5, 0xf5df9a, 1);
      });

      this.add
        .text(province.labelX, province.labelY, province.name, {
          fontFamily: "monospace",
          fontSize: "16px",
          color: "#fff6d8",
          align: "center",
        })
        .setOrigin(0.5);
    }

    const river = this.add.graphics();
    river.lineStyle(10, 0x416f82, 0.75);
    river.beginPath();
    river.moveTo(510, 95);
    river.lineTo(525, 180);
    river.lineTo(500, 265);
    river.lineTo(535, 345);
    river.strokePath();

    this.add.circle(226, 270, 10, 0xf3de9a).setStrokeStyle(3, 0x1b1b18);
    this.add
      .text(244, 263, "First Frontier Army · 1,200", {
        fontFamily: "monospace",
        fontSize: "12px",
        color: "#f4e9c6",
      })
      .setOrigin(0, 0.5);

    this.input.keyboard?.on("keydown-B", () => this.scene.start("BattleBenchmark"));
    this.#removeSceneListener = gameBridge.on("scene-requested", (event) => {
      this.startRequestedScene(event.detail);
    });
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => this.cleanup());
  }

  private startRequestedScene(scene: GameSceneId): void {
    if (scene !== this.scene.key) {
      this.scene.start(scene);
    }
  }

  private cleanup(): void {
    this.#removeSceneListener?.();
    this.#removeSceneListener = undefined;
    this.input.keyboard?.removeAllListeners();
  }
}
