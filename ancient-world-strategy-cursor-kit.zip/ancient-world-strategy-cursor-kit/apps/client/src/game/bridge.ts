export type GameSceneId = "StrategicMap" | "BattleBenchmark";

export interface RendererTelemetry {
  scene: GameSceneId;
  framesPerSecond: number;
  visualInstances: number;
  note: string;
}

interface GameBridgeEventMap {
  "scene-requested": CustomEvent<GameSceneId>;
  "province-selected": CustomEvent<string>;
  "renderer-telemetry": CustomEvent<RendererTelemetry>;
}

type GameBridgeEventName = keyof GameBridgeEventMap;

class GameBridge extends EventTarget {
  requestScene(scene: GameSceneId): void {
    this.dispatchEvent(new CustomEvent("scene-requested", { detail: scene }));
  }

  publishProvinceSelection(provinceId: string): void {
    this.dispatchEvent(new CustomEvent("province-selected", { detail: provinceId }));
  }

  publishTelemetry(telemetry: RendererTelemetry): void {
    this.dispatchEvent(new CustomEvent("renderer-telemetry", { detail: telemetry }));
  }

  on<TKey extends GameBridgeEventName>(
    type: TKey,
    listener: (event: GameBridgeEventMap[TKey]) => void,
  ): () => void {
    const eventListener = listener as EventListener;
    this.addEventListener(type, eventListener);
    return () => this.removeEventListener(type, eventListener);
  }
}

export const gameBridge = new GameBridge();
