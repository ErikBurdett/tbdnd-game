import Dexie, { type EntityTable } from "dexie";

export interface SaveRecord {
  id: string;
  campaignId: string;
  schemaVersion: number;
  contentVersion: string;
  turn: number;
  stateHash: string;
  serializedWorld: string;
  createdAt: string;
  updatedAt: string;
}

export interface ReplayRecord {
  id: string;
  campaignId: string;
  initialSnapshot: string;
  commandLog: string;
  finalStateHash: string;
  createdAt: string;
}

class AncientWorldDatabase extends Dexie {
  saves!: EntityTable<SaveRecord, "id">;
  replays!: EntityTable<ReplayRecord, "id">;

  constructor() {
    super("ancient-world-strategy");
    this.version(1).stores({
      saves: "id, campaignId, updatedAt, turn",
      replays: "id, campaignId, createdAt",
    });
  }
}

export const gameDatabase = new AncientWorldDatabase();
