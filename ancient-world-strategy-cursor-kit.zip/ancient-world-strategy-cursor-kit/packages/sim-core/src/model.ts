export const WORLD_SCHEMA_VERSION = 1 as const;

export type FactionId = string;
export type ProvinceId = string;
export type ArmyId = string;
export type CommandId = string;

export type StrategicPhase = "planning";

export interface RngStreams {
  strategicEvents: number;
  ai: number;
}

export interface FactionState {
  id: FactionId;
  name: string;
  isAi: boolean;
  treasury: number;
}

export interface ProvinceState {
  id: ProvinceId;
  name: string;
  ownerId: FactionId;
  neighborIds: ProvinceId[];
  food: number;
  unrest: number;
}

export interface ArmyState {
  id: ArmyId;
  name: string;
  ownerId: FactionId;
  provinceId: ProvinceId;
  strength: number;
  movementPoints: number;
  maxMovementPoints: number;
}

export interface WorldState {
  schemaVersion: typeof WORLD_SCHEMA_VERSION;
  contentVersion: string;
  campaignId: string;
  seed: number;
  turn: number;
  phase: StrategicPhase;
  revision: number;
  eventSequence: number;
  rngStreams: RngStreams;
  factions: Record<FactionId, FactionState>;
  provinces: Record<ProvinceId, ProvinceState>;
  armies: Record<ArmyId, ArmyState>;
  acceptedCommandIds: CommandId[];
}

export interface CommandEnvelope<TCommand extends WorldCommand = WorldCommand> {
  id: CommandId;
  actorFactionId: FactionId;
  expectedRevision: number;
  command: TCommand;
}

export type WorldCommand = MoveArmyCommand | EndTurnCommand;

export interface MoveArmyCommand {
  type: "army.move";
  armyId: ArmyId;
  destinationProvinceId: ProvinceId;
}

export interface EndTurnCommand {
  type: "strategic.end-turn";
}

export interface ArmyMovedEvent {
  type: "army.moved";
  sequence: number;
  turn: number;
  armyId: ArmyId;
  fromProvinceId: ProvinceId;
  toProvinceId: ProvinceId;
  movementPointsRemaining: number;
}

export interface ProvinceHarvestedEvent {
  type: "province.harvested";
  sequence: number;
  turn: number;
  provinceId: ProvinceId;
  foodDelta: number;
}

export interface TurnAdvancedEvent {
  type: "turn.advanced";
  sequence: number;
  turn: number;
  previousTurn: number;
}

export type WorldEvent = ArmyMovedEvent | ProvinceHarvestedEvent | TurnAdvancedEvent;

export type CommandFailureCode =
  | "revision-conflict"
  | "duplicate-command"
  | "unknown-actor"
  | "unknown-army"
  | "not-owner"
  | "unknown-province"
  | "not-adjacent"
  | "insufficient-movement"
  | "invalid-phase";

export interface CommandFailure {
  code: CommandFailureCode;
  message: string;
}

export type CommandResult =
  | {
      ok: true;
      state: WorldState;
      events: WorldEvent[];
      stateHash: string;
    }
  | {
      ok: false;
      error: CommandFailure;
    };

export interface WorldReadModel {
  turn: number;
  revision: number;
  stateHash: string;
  factions: Array<Pick<FactionState, "id" | "name" | "treasury" | "isAi">>;
  provinces: Array<Pick<ProvinceState, "id" | "name" | "ownerId" | "food" | "unrest">>;
  armies: Array<
    Pick<ArmyState, "id" | "name" | "ownerId" | "provinceId" | "strength" | "movementPoints">
  >;
}
