import { assertWorldInvariants } from "./invariants";
import {
  type CommandEnvelope,
  type CommandFailure,
  type CommandResult,
  type EndTurnCommand,
  type MoveArmyCommand,
  type WorldEvent,
  type WorldState,
} from "./model";
import { Rng32 } from "./rng";
import { hashWorld } from "./world";

function failure(code: CommandFailure["code"], message: string): CommandResult {
  return { ok: false, error: { code, message } };
}

function nextSequence(state: WorldState): number {
  state.eventSequence += 1;
  return state.eventSequence;
}

function validateEnvelope(state: WorldState, envelope: CommandEnvelope): CommandFailure | undefined {
  if (envelope.expectedRevision !== state.revision) {
    return {
      code: "revision-conflict",
      message: `Expected revision ${envelope.expectedRevision}, but the world is at ${state.revision}.`,
    };
  }
  if (state.acceptedCommandIds.includes(envelope.id)) {
    return {
      code: "duplicate-command",
      message: `Command ${envelope.id} has already been accepted.`,
    };
  }
  if (!state.factions[envelope.actorFactionId]) {
    return {
      code: "unknown-actor",
      message: `Faction ${envelope.actorFactionId} does not exist.`,
    };
  }
  if (state.phase !== "planning") {
    return {
      code: "invalid-phase",
      message: `Command ${envelope.command.type} is not legal during ${state.phase}.`,
    };
  }
  return undefined;
}

function validateMoveArmy(
  state: WorldState,
  envelope: CommandEnvelope<MoveArmyCommand>,
): CommandFailure | undefined {
  const army = state.armies[envelope.command.armyId];
  if (!army) {
    return {
      code: "unknown-army",
      message: `Army ${envelope.command.armyId} does not exist.`,
    };
  }
  if (army.ownerId !== envelope.actorFactionId) {
    return {
      code: "not-owner",
      message: `Faction ${envelope.actorFactionId} does not control army ${army.id}.`,
    };
  }
  if (!state.provinces[envelope.command.destinationProvinceId]) {
    return {
      code: "unknown-province",
      message: `Province ${envelope.command.destinationProvinceId} does not exist.`,
    };
  }
  const origin = state.provinces[army.provinceId];
  if (!origin) {
    throw new Error(`Army ${army.id} is in missing province ${army.provinceId}.`);
  }
  if (!origin.neighborIds.includes(envelope.command.destinationProvinceId)) {
    return {
      code: "not-adjacent",
      message: `${envelope.command.destinationProvinceId} is not adjacent to ${origin.id}.`,
    };
  }
  if (army.movementPoints < 1) {
    return {
      code: "insufficient-movement",
      message: `Army ${army.id} has no movement points remaining.`,
    };
  }
  return undefined;
}

function applyMoveArmy(
  state: WorldState,
  envelope: CommandEnvelope<MoveArmyCommand>,
): WorldEvent[] {
  const army = state.armies[envelope.command.armyId];
  if (!army) {
    throw new Error("Move command was applied without a validated army.");
  }
  const fromProvinceId = army.provinceId;
  army.provinceId = envelope.command.destinationProvinceId;
  army.movementPoints -= 1;

  return [
    {
      type: "army.moved",
      sequence: nextSequence(state),
      turn: state.turn,
      armyId: army.id,
      fromProvinceId,
      toProvinceId: army.provinceId,
      movementPointsRemaining: army.movementPoints,
    },
  ];
}

function applyEndTurn(state: WorldState, _command: EndTurnCommand): WorldEvent[] {
  const events: WorldEvent[] = [];
  const previousTurn = state.turn;
  const rng = new Rng32(state.rngStreams.strategicEvents);

  for (const provinceId of Object.keys(state.provinces).sort()) {
    const province = state.provinces[provinceId];
    if (!province) {
      throw new Error(`Missing province ${provinceId} during turn resolution.`);
    }
    const foodDelta = 5 + rng.intInclusive(-1, 1);
    province.food += foodDelta;
    events.push({
      type: "province.harvested",
      sequence: nextSequence(state),
      turn: previousTurn,
      provinceId,
      foodDelta,
    });
  }

  for (const factionId of Object.keys(state.factions).sort()) {
    const faction = state.factions[factionId];
    if (!faction) {
      throw new Error(`Missing faction ${factionId} during turn resolution.`);
    }
    faction.treasury += 10;
  }

  for (const armyId of Object.keys(state.armies).sort()) {
    const army = state.armies[armyId];
    if (!army) {
      throw new Error(`Missing army ${armyId} during turn resolution.`);
    }
    army.movementPoints = army.maxMovementPoints;
  }

  state.rngStreams.strategicEvents = rng.getState();
  state.turn += 1;
  events.push({
    type: "turn.advanced",
    sequence: nextSequence(state),
    turn: state.turn,
    previousTurn,
  });

  return events;
}

export function executeCommand(state: WorldState, envelope: CommandEnvelope): CommandResult {
  const envelopeFailure = validateEnvelope(state, envelope);
  if (envelopeFailure) {
    return failure(envelopeFailure.code, envelopeFailure.message);
  }

  let commandFailure: CommandFailure | undefined;
  switch (envelope.command.type) {
    case "army.move":
      commandFailure = validateMoveArmy(
        state,
        envelope as CommandEnvelope<MoveArmyCommand>,
      );
      break;
    case "strategic.end-turn":
      break;
    default: {
      const exhaustive: never = envelope.command;
      throw new Error(`Unhandled command: ${JSON.stringify(exhaustive)}`);
    }
  }

  if (commandFailure) {
    return failure(commandFailure.code, commandFailure.message);
  }

  let events: WorldEvent[];
  switch (envelope.command.type) {
    case "army.move":
      events = applyMoveArmy(state, envelope as CommandEnvelope<MoveArmyCommand>);
      break;
    case "strategic.end-turn":
      events = applyEndTurn(state, envelope.command);
      break;
    default: {
      const exhaustive: never = envelope.command;
      throw new Error(`Unhandled command: ${JSON.stringify(exhaustive)}`);
    }
  }

  state.acceptedCommandIds.push(envelope.id);
  state.revision += 1;
  assertWorldInvariants(state);

  return {
    ok: true,
    state,
    events,
    stateHash: hashWorld(state),
  };
}
