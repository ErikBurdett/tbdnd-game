import { stableHash } from "./canonical";
import { deriveSeed } from "./rng";
import {
  WORLD_SCHEMA_VERSION,
  type ArmyState,
  type FactionState,
  type ProvinceState,
  type WorldReadModel,
  type WorldState,
} from "./model";

export function createSampleWorld(seed = 10): WorldState {
  const factions: Record<string, FactionState> = {
    "faction.aurelia": {
      id: "faction.aurelia",
      name: "Aurelian Frontier",
      isAi: false,
      treasury: 120,
    },
    "faction.arsacia": {
      id: "faction.arsacia",
      name: "Arsacian March",
      isAi: true,
      treasury: 110,
    },
    "faction.orontes": {
      id: "faction.orontes",
      name: "Orontes League",
      isAi: true,
      treasury: 90,
    },
  };

  const provinces: Record<string, ProvinceState> = {
    "province.western-gate": {
      id: "province.western-gate",
      name: "Western Gate",
      ownerId: "faction.aurelia",
      neighborIds: ["province.river-crossing"],
      food: 40,
      unrest: 5,
    },
    "province.river-crossing": {
      id: "province.river-crossing",
      name: "River Crossing",
      ownerId: "faction.orontes",
      neighborIds: ["province.eastern-march", "province.western-gate"],
      food: 35,
      unrest: 12,
    },
    "province.eastern-march": {
      id: "province.eastern-march",
      name: "Eastern March",
      ownerId: "faction.arsacia",
      neighborIds: ["province.river-crossing"],
      food: 45,
      unrest: 7,
    },
  };

  const armies: Record<string, ArmyState> = {
    "army.first-frontier": {
      id: "army.first-frontier",
      name: "First Frontier Army",
      ownerId: "faction.aurelia",
      provinceId: "province.western-gate",
      strength: 1_200,
      movementPoints: 1,
      maxMovementPoints: 1,
    },
  };

  return {
    schemaVersion: WORLD_SCHEMA_VERSION,
    contentVersion: "core.prototype.1",
    campaignId: `campaign.sample.${seed >>> 0}`,
    seed: seed >>> 0,
    turn: 1,
    phase: "planning",
    revision: 0,
    eventSequence: 0,
    rngStreams: {
      strategicEvents: deriveSeed(seed, "strategic-events"),
      ai: deriveSeed(seed, "ai"),
    },
    factions,
    provinces,
    armies,
    acceptedCommandIds: [],
  };
}

export function cloneWorld(state: WorldState): WorldState {
  return JSON.parse(JSON.stringify(state)) as WorldState;
}

export function hashWorld(state: WorldState): string {
  return stableHash(state);
}

export function buildWorldReadModel(state: WorldState): WorldReadModel {
  return {
    turn: state.turn,
    revision: state.revision,
    stateHash: hashWorld(state),
    factions: Object.keys(state.factions)
      .sort()
      .map((id) => {
        const faction = state.factions[id];
        if (!faction) {
          throw new Error(`Missing faction during read-model creation: ${id}`);
        }
        return {
          id: faction.id,
          name: faction.name,
          treasury: faction.treasury,
          isAi: faction.isAi,
        };
      }),
    provinces: Object.keys(state.provinces)
      .sort()
      .map((id) => {
        const province = state.provinces[id];
        if (!province) {
          throw new Error(`Missing province during read-model creation: ${id}`);
        }
        return {
          id: province.id,
          name: province.name,
          ownerId: province.ownerId,
          food: province.food,
          unrest: province.unrest,
        };
      }),
    armies: Object.keys(state.armies)
      .sort()
      .map((id) => {
        const army = state.armies[id];
        if (!army) {
          throw new Error(`Missing army during read-model creation: ${id}`);
        }
        return {
          id: army.id,
          name: army.name,
          ownerId: army.ownerId,
          provinceId: army.provinceId,
          strength: army.strength,
          movementPoints: army.movementPoints,
        };
      }),
  };
}
