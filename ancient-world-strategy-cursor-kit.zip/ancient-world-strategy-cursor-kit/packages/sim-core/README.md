# `@ancient/sim-core`

Renderer-independent deterministic campaign simulation.

Public responsibilities:

- Campaign state and IDs.
- Seeded RNG streams.
- Commands and structured rejection.
- Ordered events.
- State invariants and canonical hashes.
- Serialization and replay.

The sample implementation intentionally uses a tiny state. Add systems through commands and explicit turn phases; never import browser/renderer code.
