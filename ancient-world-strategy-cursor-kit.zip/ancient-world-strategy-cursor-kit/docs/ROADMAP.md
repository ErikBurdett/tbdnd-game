# Development Roadmap

The roadmap is milestone-based. Calendar estimates are deliberately secondary to acceptance gates.

## Milestone 0 — Foundation

Deliver:

- Workspace installs and `pnpm check` passes.
- React + Phaser shell runs.
- Campaign worker initializes deterministic sample state.
- Strategic map and GPU benchmark scenes are accessible.
- Content and asset validation commands work.
- CI runs on a clean checkout.
- Cursor rules, skills, hooks, and agents are recognized.

Exit gate:

- Clone → install → test → dev works with documented steps.
- A second run with the same seed yields the same state hash.

## Milestone 1 — Strategic command loop

Deliver:

- Province graph.
- Faction and province state.
- Army creation/movement.
- Turn phases and command queue.
- Read models with fog-of-war filtering.
- Event log and command rejection reasons.
- Basic AI legal move.

Exit gate:

- Player and AI can complete ten deterministic turns.
- Replay equivalence test passes.

## Milestone 2 — Settlement and economy

Deliver:

- Settlement queues.
- Population/resource aggregates.
- Recruitment and upkeep.
- Supply generation/consumption.
- Three building chains.
- Four research branches.
- Tooltips with causal breakdowns.

Exit gate:

- Choices create visible tradeoffs.
- No full-world scan is required for every formula.
- A 100-turn soak preserves invariants.

## Milestone 3 — Operational armies

Deliver:

- Formations, commanders, movement posture, scouting, fatigue, supply.
- Interception and battle initiation.
- Army inspector and order preview.
- AI goal and utility skeleton.

Exit gate:

- Army state persists through movement and battle handoff.
- Invalid compositions/orders are explained.

## Milestone 4 — Formation battle

Deliver:

- Battle worker and phase state.
- Deployment.
- Formation movement/contact.
- Morale, cohesion, fatigue, casualties, rout, reserves, withdrawal.
- Renderer adapter and density profiles.
- Performance benchmark with recorded results.

Exit gate:

- One complete battle resolves deterministically.
- Visual density does not alter results.
- Outcome projects back to campaign.

## Milestone 5 — Party mission

Deliver:

- Compact tactical map.
- Individual characters and actions.
- Objective/extraction.
- One arcane mechanic.
- Campaign consequences.

Exit gate:

- Mission uses shared world characters and produces a domain event bundle.
- Save/reload works during allowed mission boundaries.

## Milestone 6 — Save, replay, and diagnostics

Deliver:

- IndexedDB save repository.
- Save migrations.
- Periodic replay checkpoints.
- Replay inspector.
- State hash and phase timing diagnostics.
- Crash recovery.

Exit gate:

- Version N-1 fixture migrates.
- Corrupt save fails safely.
- Desync can be localized to a command/phase.

## Milestone 7 — Content and usability pass

Deliver:

- Initial theater data with provenance.
- Sorceress asset pipeline.
- Onboarding.
- Accessibility baseline.
- Audio and presentation polish.
- Balance telemetry stored locally or explicitly opted in.

Exit gate:

- A new player completes the loop without developer intervention.
- All third-party assets have rights records.
- Historical/fantasy labels are consistent.

## Milestone 8 — Scale proof

Deliver:

- Larger synthetic world fixture.
- Long campaign soak.
- Memory profile.
- Multiple simultaneous battles resolved serially or in bounded workers.
- Province map LOD.
- AI budget tests.

Exit gate:

- Target synthetic counts remain within agreed turn, memory, save, and frame budgets.
- Scale is expanded only after bottlenecks are understood.

## Deferred branches

Backend, cloud saves, multiplayer, mod SDK, and WASM optimization begin as independent ADR-backed branches only after Milestone 6.
