# Strategic Map Pipeline

## Representation

The campaign map is a province graph with visual geometry, not a giant gameplay tile grid.

Each province definition contains:

- Stable ID.
- Simplified polygon or multipolygon reference.
- Adjacency edge IDs.
- Terrain/climate tags.
- Center and label anchors.
- Settlement/site IDs.
- Optional coast, river, route, and elevation references.
- Historical provenance.

The simulation uses the graph. The renderer uses geometry and prepared textures.

## Source strategy

Potential source layers must be imported through a documented, licensed pipeline. Useful categories include:

- Modern coastlines/physical geography from public-domain Natural Earth data.
- Ancient place identifiers and gazetteer points from Pleiades under its published license.
- Carefully reviewed OpenHistoricalMap extracts where feature-level licensing and quality are acceptable.
- Original province boundaries drawn for gameplay.

Historical political boundaries around 10 CE are interpretive. Store confidence and source notes; do not imply false precision.

## Build pipeline

```text
source geodata
→ normalize CRS
→ clip to theater
→ clean geometry
→ draw gameplay province boundaries
→ assign stable IDs
→ simplify into LODs
→ calculate adjacency
→ calculate anchors
→ validate topology
→ export compact runtime geometry
→ rasterize terrain/ownership helper textures
```

This is an offline toolchain, not work performed in the browser at startup.

## Runtime layers

1. Terrain base chunks.
2. Rivers/routes/coasts.
3. Province ownership/control overlay.
4. Fog/intelligence overlay.
5. Armies/settlements/sites.
6. Labels based on zoom.
7. Selection, previews, and alerts.

## LOD

Prepare multiple geometry and texture levels.

- Far zoom: theater chunks, major labels, aggregated armies.
- Mid zoom: provinces, routes, settlements.
- Near zoom: local features and detailed icons.
- Tactical maps are separate scenes.

Cull by camera bounds plus margin. Avoid thousands of live text objects.

## Selection

Options:

- Point-in-polygon against a spatial index.
- Low-resolution province-ID lookup texture.
- Simplified hit polygons.

Selection code returns a province ID. It never determines game rules.

## Adjacency

Edges are first-class data:

```ts
interface ProvinceEdgeDefinition {
  id: string;
  from: string;
  to: string;
  kind: "land" | "river-crossing" | "sea" | "mountain-pass";
  movementCost: number;
  seasonalTags: string[];
  routeId?: string;
}
```

Validate reciprocal edges unless directionality is intentional.

## Map tests

- No duplicate province IDs.
- No invalid geometry.
- Required provinces have anchors.
- Every simulation adjacency references valid provinces.
- Reachability expectations for the scenario.
- No unintended overlaps/gaps above tolerance.
- LOD preserves province identity.
- Runtime bundle stays under budget.
