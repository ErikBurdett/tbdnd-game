# Changelog

## 0.1.0 — 2026-08-16

- Initial Cursor development kit.
- Phaser/React vertical-slice scaffold.
- Deterministic strategic and typed-array battle packages.
- Rules, skills, focused subagents, hooks, prompts, CI, and documentation.

## 2026-08-16 — packaged starter kit

- Added the runnable React/Phaser client scaffold, deterministic campaign simulation, typed-array formation battle primitives, sample content, asset manifest tooling, and a 10,000-instance benchmark scene.
- Added Cursor project rules, 14 Agent Skills, three focused subagents, an edit-formatting hook, and reusable implementation/review prompts.
- Added Windows and POSIX bootstrap scripts, editor recommendations, benchmark result templates, Dependabot, a PR completion checklist, and current GitHub Actions setup.
- Added explicit validation reporting and first-install lockfile guidance.
- Completed dependency-free structure, content, asset, architecture, strict simulation-source, syntax-transpile, YAML, shell, and pure-simulation smoke checks; documented all environment-limited checks in `VALIDATION_REPORT.md`.
